<%@ page import="java.sql.*" %>
<jsp:include page="header.jsp" />


<div class="admin-header">
    <h1>Create Mock Test</h1>
</div>

<div class="admin-form">
    <form action="CreateMockTestServlet" method="post">
        <div class="form-group">
            <label>Mock Test Name</label>
            <input type="text" name="test_name" required>
        </div>

        <div class="form-group">
            <label>Duration (Minutes)</label>
            <input type="number" name="duration" required>
        </div>

        <div class="form-group">
            <label>Total Marks</label>
            <input type="number" name="total_marks" required>
        </div>

        <div class="form-group">
            <label>Total Questions</label>
            <input type="number" name="total_ques" required>
        </div>

        <div class="form-group">
            <label>Select Subject</label>
            <select name="subject_id">
            <%
                ResultSet rs = (ResultSet)request.getAttribute("subjects");
                if(rs != null) {
                    while(rs.next()) {
            %>
                <option value="<%=rs.getInt("subject_id")%>">
                    <%=rs.getString("subject_name")%>
                </option>
            <%
                    }
                } else {
            %>
                <option value="">No Subjects Available</option>
            <%
                }
            %>
            </select>
        </div>
        <div class="form-group">
    <label>Google Form Link (Embed Link)</label>
    <input type="url" name="form_link" placeholder="https://docs.google.com/forms/d/e/.../viewform" required>
</div>
        <button type="submit" class="btn-submit">Create Mock Test</button>
    </form>
</div>

</main> 
</div> 

<jsp:include page="footer.jsp" />